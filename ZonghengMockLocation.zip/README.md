# 纵横定位诊断

这是定位诊断工具，不做绕过、不隐藏模拟定位、不伪造基站或 WiFi。

功能：
- 显示 GPS/Network/Passive/Fused lastLocation
- 显示位置是否为 mock
- 显示定位权限状态
- 显示 WiFi SSID/BSSID/附近 WiFi 数量
- 显示基站信息
- 显示 VPN/网络类型/本机 IP

适合判断：
- Mock 是否生效
- 地图是否读取 Mock
- WiFi/基站环境是否与 GPS 坐标不一致
