package com.zongheng.mocklocation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.widget.Toast
import com.google.android.gms.location.LocationServices
import java.util.Timer
import java.util.TimerTask

class MockLocationService : Service() {

    private val channelId = "mock_location_channel"
    private var timer: Timer? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(1, createNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val lat = intent?.getDoubleExtra("lat", 0.0) ?: 0.0
        val lng = intent?.getDoubleExtra("lng", 0.0) ?: 0.0
        startMockLocation(lat, lng)
        return START_STICKY
    }

    private fun startMockLocation(lat: Double, lng: Double) {
        val client = LocationServices.getFusedLocationProviderClient(this)

        client.setMockMode(true)
            .addOnSuccessListener {
                timer?.cancel()
                timer = Timer()

                timer?.scheduleAtFixedRate(object : TimerTask() {
                    override fun run() {
                        val location = Location("fused").apply {
                            latitude = lat
                            longitude = lng
                            accuracy = 5f
                            altitude = 10.0
                            speed = 0f
                            bearing = 0f
                            time = System.currentTimeMillis()
                            elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
                        }
                        client.setMockLocation(location)
                    }
                }, 0, 1000)
            }
            .addOnFailureListener {
                Toast.makeText(
                    this,
                    "启动失败：请在开发者选项中选择本 App 为模拟位置信息应用",
                    Toast.LENGTH_LONG
                ).show()
                stopSelf()
            }
    }

    override fun onDestroy() {
        timer?.cancel()
        timer = null

        val client = LocationServices.getFusedLocationProviderClient(this)
        client.setMockMode(false)

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotification(): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("纵横虚拟定位")
                .setContentText("虚拟定位运行中")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("纵横虚拟定位")
                .setContentText("虚拟定位运行中")
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "虚拟定位服务",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
