package com.zongheng.locationdiagnose

import android.Manifest
import android.annotation.SuppressLint
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.telephony.CellInfo
import android.telephony.CellInfoCdma
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoTdscdma
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var output: TextView

    private val requiredPermissions: Array<String>
        get() {
            val list = mutableListOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_WIFI_STATE,
                Manifest.permission.READ_PHONE_STATE
            )
            if (Build.VERSION.SDK_INT >= 33) {
                list.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            }
            return list.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestNeededPermissions()
        runDiagnose()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 28)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val title = TextView(this).apply {
            text = "纵横定位诊断"
            textSize = 28f
            setTextColor(0xFF111111.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))

        val desc = TextView(this).apply {
            text = "只读取定位来源、WiFi、基站、权限和模拟定位状态，用于判断地图测试为什么不跟随。不会伪造基站或绕过校验。"
            textSize = 14f
            setTextColor(0xFF666666.toInt())
            setPadding(0, 18, 0, 18)
        }
        root.addView(desc, LinearLayout.LayoutParams(-1, -2))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val refresh = Button(this).apply {
            text = "重新检测"
            setOnClickListener { runDiagnose() }
        }
        val settings = Button(this).apply {
            text = "开发者选项"
            setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
        }
        row.addView(refresh, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(settings, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row, LinearLayout.LayoutParams(-1, -2))

        output = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF222222.toInt())
            setPadding(0, 20, 0, 0)
            movementMethod = ScrollingMovementMethod()
            setTextIsSelectable(true)
        }
        root.addView(output, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        runDiagnose()
    }

    private fun hasFineLocation(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun hasCoarseLocation(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    private fun runDiagnose() {
        val sb = StringBuilder()
        sb.appendLine("检测时间：${timeNow()}")
        sb.appendLine("设备：${Build.MANUFACTURER} ${Build.MODEL}")
        sb.appendLine("Android：${Build.VERSION.RELEASE} / SDK ${Build.VERSION.SDK_INT}")
        sb.appendLine()

        sb.appendLine("=== 权限状态 ===")
        for (p in requiredPermissions) {
            sb.appendLine("${p.substringAfterLast('.')}: ${granted(p)}")
        }
        sb.appendLine("位置信息开关：${isLocationEnabled()}")
        sb.appendLine()

        sb.appendLine("=== 模拟定位状态 ===")
        sb.appendLine("本 App 是否可能被选为模拟定位：${isThisAppMockCandidate()}")
        sb.appendLine("系统 mock_location_app 字段：${getMockLocationSetting()}")
        sb.appendLine("提示：Android 新版本这个字段可能为空，以开发者选项页面为准。")
        sb.appendLine()

        sb.appendLine("=== 系统 LocationManager 最后位置 ===")
        sb.appendLine(getProviderLocation(LocationManager.GPS_PROVIDER))
        sb.appendLine(getProviderLocation(LocationManager.NETWORK_PROVIDER))
        sb.appendLine(getProviderLocation(LocationManager.PASSIVE_PROVIDER))
        sb.appendLine()

        sb.appendLine("=== Google Fused 最后位置 ===")
        sb.appendLine("读取中，如果下面没有更新，说明 Google 服务没有返回 lastLocation。")
        output.text = sb.toString()

        readFusedLocation(sb)
    }

    @SuppressLint("MissingPermission")
    private fun readFusedLocation(base: StringBuilder) {
        if (!hasFineLocation() && !hasCoarseLocation()) {
            base.appendLine("Fused：无定位权限")
            appendNetworkWifiCell(base)
            return
        }

        try {
            val client = LocationServices.getFusedLocationProviderClient(this)
            client.lastLocation
                .addOnSuccessListener { loc ->
                    base.appendLine(formatLocation("Fused", loc))
                    appendNetworkWifiCell(base)
                }
                .addOnFailureListener { e ->
                    base.appendLine("Fused：读取失败 ${e.javaClass.simpleName}: ${e.message}")
                    appendNetworkWifiCell(base)
                }
        } catch (e: Exception) {
            base.appendLine("Fused：异常 ${e.javaClass.simpleName}: ${e.message}")
            appendNetworkWifiCell(base)
        }
    }

    private fun appendNetworkWifiCell(sb: StringBuilder) {
        sb.appendLine()
        sb.appendLine("=== 网络环境 ===")
        sb.appendLine(getNetworkSummary())
        sb.appendLine("本机局域网 IP：${getLocalIps()}")
        sb.appendLine()

        sb.appendLine("=== WiFi 环境 ===")
        sb.appendLine(getWifiSummary())
        sb.appendLine()

        sb.appendLine("=== 基站环境 ===")
        sb.appendLine(getCellSummary())
        sb.appendLine()

        sb.appendLine("=== 判断参考 ===")
        sb.appendLine("1. 如果 GPS/Fused 显示目标坐标，但 WiFi/基站仍是本地环境，说明环境校验会不一致。")
        sb.appendLine("2. 如果 GPS/Fused 都还是原位置，说明模拟定位没有真正生效。")
        sb.appendLine("3. 如果普通测试工具变了，但高德不变，说明高德定位源或缓存不跟随普通 Mock。")
        sb.appendLine("4. 本工具只做诊断，不做绕过、隐藏、伪造基站/WiFi。")

        output.text = sb.toString()
    }

    private fun granted(permission: String): String {
        return if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) "已允许" else "未允许"
    }

    private fun isLocationEnabled(): String {
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (Build.VERSION.SDK_INT >= 28) {
                if (lm.isLocationEnabled) "已开启" else "未开启"
            } else {
                val mode = Settings.Secure.getInt(contentResolver, Settings.Secure.LOCATION_MODE)
                if (mode != Settings.Secure.LOCATION_MODE_OFF) "已开启" else "未开启"
            }
        } catch (e: Exception) {
            "未知：${e.message}"
        }
    }

    private fun isThisAppMockCandidate(): String {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, android.os.Process.myUid(), packageName)
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(AppOpsManager.OPSTR_MOCK_LOCATION, android.os.Process.myUid(), packageName)
            }
            when (mode) {
                AppOpsManager.MODE_ALLOWED -> "是，AppOps 允许 Mock"
                AppOpsManager.MODE_IGNORED -> "否，AppOps 忽略 Mock"
                AppOpsManager.MODE_ERRORED -> "否，AppOps 错误"
                else -> "未知，AppOps mode=$mode"
            }
        } catch (e: Exception) {
            "无法判断：${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun getMockLocationSetting(): String {
        return try {
            Settings.Secure.getString(contentResolver, "mock_location_app") ?: "空/不可读"
        } catch (e: Exception) {
            "不可读：${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun getProviderLocation(provider: String): String {
        if (!hasFineLocation() && !hasCoarseLocation()) return "$provider：无定位权限"
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val enabled = try { lm.isProviderEnabled(provider) } catch (_: Exception) { false }
            val loc = try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null }
            "$provider：enabled=$enabled\n${formatLocation(provider, loc)}"
        } catch (e: Exception) {
            "$provider：异常 ${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun formatLocation(name: String, loc: Location?): String {
        if (loc == null) return "$name：无 lastLocation"
        val mock = if (Build.VERSION.SDK_INT >= 31) loc.isMock else @Suppress("DEPRECATION") loc.isFromMockProvider
        val t = try { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(loc.time)) } catch (_: Exception) { loc.time.toString() }
        return buildString {
            appendLine("$name：")
            appendLine("  纬度=${loc.latitude}")
            appendLine("  经度=${loc.longitude}")
            appendLine("  精度=${loc.accuracy}m")
            appendLine("  来源=${loc.provider}")
            appendLine("  是否模拟=${mock}")
            appendLine("  时间=$t")
        }
    }

    private fun getNetworkSummary(): String {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork ?: return "无活动网络"
            val caps = cm.getNetworkCapabilities(network) ?: return "无法读取网络能力"
            val type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "移动数据"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "有线网络"
                else -> "其他"
            }
            "当前网络：$type，VPN=${caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)}"
        } catch (e: Exception) {
            "读取失败：${e.javaClass.simpleName}: ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun getWifiSummary(): String {
        return try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val info: WifiInfo? = wm.connectionInfo
            val ssid = info?.ssid ?: "未知"
            val bssid = info?.bssid ?: "未知"
            val rssi = info?.rssi ?: 0
            val sb = StringBuilder()
            sb.appendLine("WiFi 开关：${if (wm.isWifiEnabled) "开启" else "关闭"}")
            sb.appendLine("当前 SSID：$ssid")
            sb.appendLine("当前 BSSID：$bssid")
            sb.appendLine("当前 RSSI：$rssi")
            val scans = try { wm.scanResults.orEmpty() } catch (e: Exception) { emptyList() }
            sb.appendLine("附近 WiFi 数量：${scans.size}")
            scans.take(12).forEachIndexed { index, s ->
                sb.appendLine("${index + 1}. SSID=${s.SSID}, BSSID=${s.BSSID}, level=${s.level}, freq=${s.frequency}")
            }
            sb.toString()
        } catch (e: Exception) {
            "读取失败：${e.javaClass.simpleName}: ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun getCellSummary(): String {
        if (!hasFineLocation()) return "无精确定位权限，无法读取基站信息"
        return try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val cells: List<CellInfo> = try { tm.allCellInfo.orEmpty() } catch (e: Exception) { emptyList() }
            if (cells.isEmpty()) return "未读取到基站信息，可能被系统限制或权限不足"
            val sb = StringBuilder()
            sb.appendLine("基站数量：${cells.size}")
            cells.take(10).forEachIndexed { i, c -> sb.appendLine("${i + 1}. ${cellToText(c)}") }
            sb.toString()
        } catch (e: Exception) {
            "读取失败：${e.javaClass.simpleName}: ${e.message}"
        }
    }

    private fun cellToText(cell: CellInfo): String {
        return try {
            when (cell) {
                is CellInfoLte -> "LTE registered=${cell.isRegistered}, ci=${cell.cellIdentity.ci}, tac=${cell.cellIdentity.tac}, pci=${cell.cellIdentity.pci}, earfcn=${cell.cellIdentity.earfcn}, dbm=${cell.cellSignalStrength.dbm}"
                is CellInfoNr -> if (Build.VERSION.SDK_INT >= 29) "NR/5G registered=${cell.isRegistered}, id=${cell.cellIdentity}, signal=${cell.cellSignalStrength}" else "NR/5G"
                is CellInfoWcdma -> "WCDMA registered=${cell.isRegistered}, cid=${cell.cellIdentity.cid}, lac=${cell.cellIdentity.lac}, psc=${cell.cellIdentity.psc}, dbm=${cell.cellSignalStrength.dbm}"
                is CellInfoGsm -> "GSM registered=${cell.isRegistered}, cid=${cell.cellIdentity.cid}, lac=${cell.cellIdentity.lac}, arfcn=${cell.cellIdentity.arfcn}, dbm=${cell.cellSignalStrength.dbm}"
                is CellInfoCdma -> "CDMA registered=${cell.isRegistered}, baseId=${cell.cellIdentity.basestationId}, networkId=${cell.cellIdentity.networkId}, dbm=${cell.cellSignalStrength.dbm}"
                is CellInfoTdscdma -> if (Build.VERSION.SDK_INT >= 29) "TDSCDMA registered=${cell.isRegistered}, cid=${cell.cellIdentity.cid}, lac=${cell.cellIdentity.lac}, dbm=${cell.cellSignalStrength.dbm}" else "TDSCDMA"
                else -> cell.toString()
            }
        } catch (e: Exception) {
            "${cell.javaClass.simpleName} 解析失败：${e.message}"
        }
    }

    private fun getLocalIps(): String {
        return try {
            val ips = NetworkInterface.getNetworkInterfaces().toList().flatMap { ni ->
                ni.inetAddresses.toList().filter { !it.isLoopbackAddress }.map { it.hostAddress ?: "" }
            }.filter { it.isNotBlank() }
            if (ips.isEmpty()) "无" else ips.joinToString(", ")
        } catch (e: Exception) {
            "读取失败：${e.message}"
        }
    }

    private fun timeNow(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date())
}
