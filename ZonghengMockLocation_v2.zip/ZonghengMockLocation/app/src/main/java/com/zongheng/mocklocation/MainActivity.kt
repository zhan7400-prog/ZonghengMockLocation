package com.zongheng.mocklocation

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var latInput: EditText
    private lateinit var lngInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        latInput = findViewById(R.id.latInput)
        lngInput = findViewById(R.id.lngInput)
        statusText = findViewById(R.id.statusText)

        val startBtn: Button = findViewById(R.id.startBtn)
        val stopBtn: Button = findViewById(R.id.stopBtn)
        val devBtn: Button = findViewById(R.id.devBtn)

        requestNeededPermissions()

        devBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }

        startBtn.setOnClickListener {
            val lat = latInput.text.toString().trim().toDoubleOrNull()
            val lng = lngInput.text.toString().trim().toDoubleOrNull()

            if (lat == null || lng == null) {
                toast("请输入正确经纬度")
                return@setOnClickListener
            }

            if (lat !in -90.0..90.0 || lng !in -180.0..180.0) {
                toast("经纬度范围不正确")
                return@setOnClickListener
            }

            val intent = Intent(this, MockLocationService::class.java)
            intent.putExtra("lat", lat)
            intent.putExtra("lng", lng)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }

            statusText.text = "状态：运行中，纬度 $lat，经度 $lng"
            toast("已开始虚拟定位")
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, MockLocationService::class.java))
            statusText.text = "状态：已停止"
            toast("已停止虚拟定位")
        }
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val needRequest = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }

        if (needRequest.isNotEmpty()) {
            requestPermissions(needRequest.toTypedArray(), 1001)
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}
