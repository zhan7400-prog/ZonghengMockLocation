package com.zongheng.mocklocation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Criteria
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.widget.Toast
import com.google.android.gms.location.LocationServices
import java.util.Timer
import java.util.TimerTask

class MockLocationService : Service() {

    private val channelId = "mock_location_channel"
    private var timer: Timer? = null
    private lateinit var locationManager: LocationManager
    private val providers = listOf(
        LocationManager.GPS_PROVIDER,
        LocationManager.NETWORK_PROVIDER,
        LocationManager.PASSIVE_PROVIDER
    )

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        createNotificationChannel()
        startForeground(1, createNotification("虚拟定位运行中"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val lat = intent?.getDoubleExtra("lat", 0.0) ?: 0.0
        val lng = intent?.getDoubleExtra("lng", 0.0) ?: 0.0
        startMockLocation(lat, lng)
        return START_STICKY
    }

    private fun startMockLocation(lat: Double, lng: Double) {
        val fusedClient = LocationServices.getFusedLocationProviderClient(this)

        try {
            prepareTestProviders()
        } catch (e: SecurityException) {
            showFail("启动失败：请在开发者选项中选择本 App 为模拟位置信息应用")
            return
        } catch (e: Exception) {
            // Some ROMs restrict one or more providers. Continue with Fused mock mode below.
        }

        fusedClient.setMockMode(true)
            .addOnSuccessListener {
                timer?.cancel()
                timer = Timer()

                timer?.scheduleAtFixedRate(object : TimerTask() {
                    override fun run() {
                        val now = System.currentTimeMillis()
                        val elapsed = SystemClock.elapsedRealtimeNanos()

                        // 1) Mock Android framework providers: gps / network / passive
                        providers.forEach { provider ->
                            try {
                                val location = buildLocation(provider, lat, lng, now, elapsed)
                                locationManager.setTestProviderLocation(provider, location)
                            } catch (_: Exception) {
                            }
                        }

                        // 2) Mock Google Fused provider
                        try {
                            val fusedLocation = buildLocation("fused", lat, lng, now, elapsed)
                            fusedClient.setMockLocation(fusedLocation)
                        } catch (_: Exception) {
                        }
                    }
                }, 0, 1000)
            }
            .addOnFailureListener {
                showFail("启动失败：请在开发者选项中选择本 App 为模拟位置信息应用")
            }
    }

    private fun prepareTestProviders() {
        providers.forEach { provider ->
            try {
                locationManager.removeTestProvider(provider)
            } catch (_: Exception) {
            }

            try {
                @Suppress("DEPRECATION")
                locationManager.addTestProvider(
                    provider,
                    false,
                    false,
                    false,
                    false,
                    true,
                    true,
                    true,
                    Criteria.POWER_LOW,
                    Criteria.ACCURACY_FINE
                )
            } catch (_: IllegalArgumentException) {
                // Provider may already exist on some devices.
            }

            try {
                locationManager.setTestProviderEnabled(provider, true)
            } catch (_: Exception) {
            }
        }
    }

    private fun buildLocation(
        provider: String,
        lat: Double,
        lng: Double,
        now: Long,
        elapsed: Long
    ): Location {
        return Location(provider).apply {
            latitude = lat
            longitude = lng
            accuracy = 3f
            altitude = 10.0
            speed = 0f
            bearing = 0f
            time = now
            elapsedRealtimeNanos = elapsed
            extras = Bundle().apply {
                putInt("satellites", 12)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                verticalAccuracyMeters = 3f
                speedAccuracyMetersPerSecond = 0.1f
                bearingAccuracyDegrees = 0.1f
            }
        }
    }

    private fun showFail(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        stopSelf()
    }

    override fun onDestroy() {
        timer?.cancel()
        timer = null

        val fusedClient = LocationServices.getFusedLocationProviderClient(this)
        fusedClient.setMockMode(false)

        providers.forEach { provider ->
            try {
                locationManager.setTestProviderEnabled(provider, false)
            } catch (_: Exception) {
            }
            try {
                locationManager.removeTestProvider(provider)
            } catch (_: Exception) {
            }
        }

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
                .setContentTitle("纵横虚拟定位")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("纵横虚拟定位")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_mylocation)
                .build()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "虚拟定位服务",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
